# CR-Assist: VS Code Integration & Implementation Guide

This guide explains how to use the provided prompts, schemas, and reference files to build and run the **Change Request AI Assistant (CR-Assist)** within **Visual Studio Code (VS Code)** using AI agents (GitHub Copilot, Antigravity, Claude Dev/Roo Code, Cursor, etc.).

---

## 1. Project Directory Structure

```text
Ai_friday_team-gsk/
├── .vscode/
│   ├── settings.json                   # Recommended workspace settings
│   └── tasks.json                      # VS Code tasks to run frontend & backend
├── references/
│   ├── change_request_schema.json      # JSON schema for CRs and AI analysis results
│   ├── sample_change_requests.json     # 4 realistic enterprise test CRs
│   ├── impact_rubric.md                # Objective 1-5 scoring criteria & priority formulas
│   └── llm_prompts.md                  # System prompts & JSON templates for LLM
├── PROMPT.md                           # Master prompt for the AI coding agent
├── INSTRUCTIONS.md                     # This developer & integration guide
└── .github/
    └── copilot-instructions.md         # Auto-loaded context instructions for GitHub Copilot
```

---

## 2. Using with VS Code AI Assistants

### Option A: Using GitHub Copilot in VS Code
1. The file `.github/copilot-instructions.md` is automatically recognized by GitHub Copilot Chat in VS Code.
2. Open Copilot Chat (`Ctrl + Alt + I` or `Cmd + Alt + I`).
3. Type:
   ```text
   @workspace Read PROMPT.md and references/impact_rubric.md. Let's start by scaffolding the project architecture.
   ```

### Option B: Using Antigravity / Agentic Coding Extension
1. You can instruct the agent in the chat:
   ```text
   Please implement the solution defined in PROMPT.md using FastAPI for backend and React + Tailwind for frontend. Refer to references/impact_rubric.md for scoring logic.
   ```
2. The agent will read `PROMPT.md`, generate code, create endpoints, and build the UI components automatically.

---

## 3. Architecture Overview

```mermaid
flowchart TD
    subgraph Data Sources
        JIRA["Jira / ServiceNow Mock API"]
        FORM["Direct CR Web Submission"]
        JSON_SEED["references/sample_change_requests.json"]
    end

    subgraph Backend API [FastAPI / Express]
        INGEST["Ingestion Service & Validator"]
        AI_ENGINE["AI Impact & Scoring Engine"]
        RUBRIC["Scoring Formula Engine\n(references/impact_rubric.md)"]
        CHAT_SERVICE["NL Query & Search Service"]
        DB[(Local SQLite / JSON DB)]
    end

    subgraph LLM Provider
        LLM["Gemini / OpenAI / Ollama\n(Structured JSON output)"]
    end

    subgraph Frontend [React + Tailwind]
        DASH["Dashboard & KPI Analytics"]
        CR_LIST["CR Queue with Filters & Badges"]
        DOSSIER["Impact Dossier & Dependency View"]
        CHAT_UI["NL Query Assistant Console"]
        FEEDBACK["Human Calibration & Overrides"]
    end

    JIRA --> INGEST
    FORM --> INGEST
    JSON_SEED --> INGEST
    INGEST --> DB
    INGEST --> AI_ENGINE
    AI_ENGINE <--> LLM
    AI_ENGINE --> RUBRIC
    RUBRIC --> DB
    CHAT_SERVICE <--> LLM
    DB --> CHAT_SERVICE
    DB --> DASH
    DB --> CR_LIST
    DB --> DOSSIER
    DOSSIER --> FEEDBACK
    FEEDBACK --> DB
```

---

## 4. Implementation Checklist for the Prototype

- [ ] **Step 1: Backend Data Models & Scoring Logic**
  - Implement Pydantic or TypeScript models matching `references/change_request_schema.json`.
  - Implement deterministic priority score calculation function:
    $$\text{Score} = (BV \times 0.35 + U \times 0.25 + (6 - C) \times 0.20 + (6 - R) \times 0.20) \times 20$$
  - Map score to `P1-Critical`, `P2-High`, `P3-Medium`, or `P4-Low`.

- [ ] **Step 2: AI Analysis Pipeline**
  - Integrate LLM client using prompts from `references/llm_prompts.md`.
  - Add fallback mock analysis generator in case no API key is configured or offline.
  - Implement dependency parsing (tagging databases, APIs, microservices).

- [ ] **Step 3: Ticketing API Integration**
  - Create `/api/ticketing/sync` endpoint that simulates pulling tickets from Jira or ServiceNow.
  - Allow loading `references/sample_change_requests.json` into the active workspace.

- [ ] **Step 4: Natural Language Query Endpoint**
  - Implement `/api/chat/query` endpoint that sends question + active CR summaries to LLM for conversational insights.

- [ ] **Step 5: Frontend Dashboard & Visualizations**
  - KPI Cards: Total CRs, High Risk, Analyzed, Average Priority Score.
  - 2x2 Impact vs. Effort matrix or Risk distribution chart.
  - Filterable list of CRs with search, status filters, and priority tags.
  - Detailed modal/drawer displaying the AI Executive Summary, Technical Dependencies, and Test Checklist.
  - Thumbs up/down feedback buttons and priority override with notes.

- [ ] **Step 6: Basic Error Handling & User Feedback**
  - Toast notifications for API errors.
  - Graceful degradation if LLM returns malformed JSON (retry or fallback).
  - Feedback submission stored to audit log.

---

## 5. Verification & Testing

To test the prototype:
1. **Load Test Data**: Load `references/sample_change_requests.json`.
2. **Run Analysis**: Trigger analysis on `CR-2024-001` (Stripe Payment Migration) and ensure it flags database changes and critical payment dependencies.
3. **Check Score**: Verify `CR-2024-002` (SMS template change) receives low risk / low complexity and calculates ~P3.
4. **Test NL Chat**: Ask *"Which change requests modify database schemas?"* and check that the AI correctly identifies `CR-2024-001`.
5. **Submit Feedback**: Override a priority recommendation and verify the change persists.
