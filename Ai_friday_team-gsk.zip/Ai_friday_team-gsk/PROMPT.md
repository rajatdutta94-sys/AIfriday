# Change Request AI Assistant (CR-Assist) — Master Build Prompt

> **Role & Objective**:  
> You are a Principal Full-Stack AI Engineer. Your mission is to build **CR-Assist**, a full-featured web-based AI assistant that streamlines Change Request (CR) analysis, breaks communication silos between business and technical teams, detects hidden technical dependencies, scores impact/risks, and recommends intelligent prioritization.

---

## 1. Problem Context & Core Value Proposition

| Current Challenge | Business / Delivery Impact | Solution Feature |
| :--- | :--- | :--- |
| **Manual CR analysis is time-consuming & subjective** | Project delays, inconsistent prioritization | Automated AI summarization, objective scoring rubric (1–10 impact & urgency score) |
| **Limited visibility into technical dependencies** | Scope creep, implementation errors, outages | Dependency graph extraction (APIs, databases, services, downstream consumers) |
| **Fragmented business-technical communication** | Misunderstandings, rework, misaligned expectations | Dual-perspective synthesis: Technical breakdown + Business summary in plain language |
| **Lack of automated documentation & summaries** | Knowledge gaps, reduced auditability/traceability | Auto-generated CR dossiers, exported reports (Markdown/PDF), audit logs |

---

## 2. Technical Stack Recommendation (Modular & Lightweight)

- **Frontend**: React (Vite / Next.js) + Tailwind CSS + Lucide Icons + Recharts / Chart.js (for analytics & dashboard).
- **Backend API**: Python FastAPI or Node.js/Express with typed schemas (Pydantic / Zod).
- **AI/LLM Engine**: OpenAI / Anthropic / Google Gemini API or local Ollama with structured JSON outputs.
- **Data Store**: SQLite / PostgreSQL with SQLAlchemy or Prisma (in-memory/SQLite default for zero-setup prototype).
- **Ticketing Integration**: Pluggable adapter pattern (`ITicketingService`) supporting Mock Jira / ServiceNow REST API endpoints with sync capabilities.

---

## 3. Core Functional Requirements

### 3.1. Change Request Ingestion & Management
- Direct manual input form (Title, Requester, Business Justification, Systems Affected, Description, Desired Timeline).
- Batch JSON / CSV import support.
- Simulated Ticketing API Webhook / Sync button (fetches mock or real tickets from Jira/ServiceNow).

### 3.2. AI-Powered Analysis Engine
For every CR, the engine must produce:
1. **Executive Summary**: 2-3 sentences explaining the "why" and "what" in non-technical terms.
2. **Technical Impact Breakdown**:
   - Affected architectural layers (UI, API, Data Layer, Cloud Infrastructure).
   - Upstream & downstream dependencies.
   - Identified breaking change risks & regression vectors.
3. **Objective Prioritization & Scoring**:
   - Business Value (1–5), Urgency (1–5), Technical Complexity (1–5), Implementation Risk (1–5).
   - Calculated Priority Score: `(Business Value * 0.35) + (Urgency * 0.25) + ((6 - Complexity) * 0.20) + ((6 - Risk) * 0.20)` scaled to 100%.
   - Category Recommendation: `Critical / P1`, `High / P2`, `Medium / P3`, `Low / P4`.
4. **Suggested Acceptance Criteria & Test Scenarios**: Bulleted test checklist.

### 3.3. Natural Language Querying (Chat / Ask CR Assistant)
- Global search and conversational Q&A interface across all analyzed CRs.
- Supports contextual questions such as:
  - *"Which CRs scheduled for Sprint 24 affect the Payment Gateway?"*
  - *"List all High Risk CRs with database schema modifications."*
  - *"Summarize the potential risks if we expedite CR-102."*

### 3.4. Interactive Dashboard & Visualizations
- **KPI Metrics Cards**: Total Active CRs, High Risk CRs, Average Processing Time Saved, P1/P2 vs P3/P4 distribution.
- **Charts**:
  - Impact vs. Effort 2x2 Matrix.
  - Risk Distribution (Low / Moderate / High / Severe).
  - Systems Affected frequency bar chart.
- **Interactive CR Table**: Filterable by status, priority, impacted system, search query.

### 3.5. Human-in-the-Loop Feedback & Calibration
- Thumbs up / down on AI recommendations.
- Override capability: Leads can adjust priority or risk score with an explanation note.
- AI calibration log capturing user adjustments to improve future prompt few-shots.

### 3.6. Robust Error Handling & Edge Cases
- Graceful fallback when LLM API rate limits occur (mock fallback mode).
- Form validation with clear inline error messages.
- Input sanitization and token limit handling for lengthy documents.

---

## 4. UI/UX Specifications

- **Clean modern enterprise layout**: Sidebar navigation (Dashboard, Change Requests, New Analysis, NL Query / Chat, Settings).
- **Color-coded badges**:
  - Priority: Red (Critical), Orange (High), Yellow (Medium), Green (Low).
  - Risk: Red (High), Amber (Medium), Green (Low).
- **Responsive design**: Works on desktop and tablet viewports.

---

## 5. Execution Steps for the Coding Agent

1. **Setup project structure**: Initialize frontend (`client/`) and backend (`server/`).
2. **Implement Data Models**: Create CR entity, Analysis entity, Feedback entity, and Ticketing API schemas.
3. **Build AI Engine & Prompts**: Incorporate few-shot templates from `references/llm_prompts.md`.
4. **Build REST Endpoints**:
   - `POST /api/cr/analyze`: Analyzes new or existing CR.
   - `GET /api/cr`: Lists all CRs with filtering and pagination.
   - `GET /api/cr/:id`: Retrieves full dossier with analysis.
   - `POST /api/chat/query`: Natural language query over the CR catalog.
   - `POST /api/cr/:id/feedback`: Submits human feedback.
   - `GET /api/ticketing/sync`: Fetches and syncs external tickets.
5. **Develop UI Components**: Dashboard, Analysis Result Drawer/Modal, NL Chat Console, and Settings.
6. **Provide seed demo data**: Load samples from `references/sample_change_requests.json`.
7. **Write Unit & Integration Tests**: Verify score calculations, fallback handlers, and API endpoints.
