"""
Scoring and Prioritization Calculation Engine
Adheres strictly to the rubric defined in references/impact_rubric.md.
"""
from typing import Literal

def calculate_priority_score(
    business_value: int,
    urgency: int,
    complexity: int,
    risk: int
) -> float:
    """
    Formula from references/impact_rubric.md:
    Priority Score = (BV * 0.35 + U * 0.25 + (6 - C) * 0.20 + (6 - R) * 0.20) * 20
    Clamped between 0.0 and 100.0, rounded to 1 decimal place.
    """
    raw_score = (
        (business_value * 0.35) +
        (urgency * 0.25) +
        ((6 - complexity) * 0.20) +
        ((6 - risk) * 0.20)
    ) * 20.0
    
    score = round(max(0.0, min(100.0, raw_score)), 1)
    return score

def map_score_to_priority(score: float) -> Literal["P1-Critical", "P2-High", "P3-Medium", "P4-Low"]:
    """
    Tier thresholds:
    >= 82: P1-Critical
    65 - 81.9: P2-High
    45 - 64.9: P3-Medium
    < 45: P4-Low
    """
    if score >= 82.0:
        return "P1-Critical"
    elif score >= 65.0:
        return "P2-High"
    elif score >= 45.0:
        return "P3-Medium"
    else:
        return "P4-Low"
