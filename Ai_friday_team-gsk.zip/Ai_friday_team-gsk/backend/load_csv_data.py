"""
Utility to convert references/change_requests_50.csv into our standard ChangeRequest schema
and seed the datastore with rich AI analysis for all 50 items.
"""

import csv
import json
import os
import sys

# Ensure root is on path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from backend.models import ChangeRequest, RequesterInfo
from backend.ai_engine import analyze_change_request
from backend.ticketing import ticket_store

CSV_PATH = os.path.join(os.path.dirname(__file__), "..", "references", "change_requests_50.csv")
SAMPLE_JSON_PATH = os.path.join(os.path.dirname(__file__), "..", "references", "sample_change_requests.json")
DATA_JSON_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "change_requests.json")

def load_and_convert_csv():
    if not os.path.exists(CSV_PATH):
        print(f"CSV file not found at {CSV_PATH}")
        return

    change_requests = []
    with open(CSV_PATH, mode="r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cr_id = row.get("Change ID", "").strip()
            if not cr_id or not cr_id.startswith("CR-"):
                continue

            title = row.get("Change Title", "").strip()
            desc = row.get("Change Description", "").strip()
            impl_plan = row.get("Implementation Plan", "").strip()
            raw_desc = f"{desc} | Implementation Plan: {impl_plan}"

            requester_name = row.get("Requester", "IT Staff").strip()
            dept = row.get("Department / Project", "Engineering").strip()
            justification = row.get("Business Justification", "Operational maintenance").strip()
            affected_ci = row.get("Affected Service / CI", "").strip()
            systems = [affected_ci] if affected_ci else ["General IT Infrastructure"]

            submitted_date = row.get("Requested Date", "2026-10-01T00:00:00Z")
            status = row.get("Change Status", "Under Review").strip()

            # Run AI Analysis Engine to generate complete dossier
            analysis = analyze_change_request(
                title=title,
                business_justification=justification,
                raw_description=raw_desc,
                affected_systems=systems
            )

            # Map the CSV's provided priority into the score if needed
            csv_priority = row.get("Priority", "").strip()
            if csv_priority == "Critical" or csv_priority == "High":
                if analysis.impactScores.priorityScore < 70:
                    analysis.impactScores.priorityScore = 84.0
                    analysis.impactScores.recommendedPriority = "P1-Critical" if csv_priority == "Critical" else "P2-High"

            cr = ChangeRequest(
                id=cr_id,
                title=title,
                requester=RequesterInfo(
                    name=requester_name,
                    department=dept,
                    email=f"{requester_name.lower().replace(' ', '.')}@enterprise.org"
                ),
                businessJustification=justification,
                rawDescription=raw_desc,
                affectedSystems=systems,
                targetReleaseDate=row.get("Planned Start", "").split(" ")[0] if row.get("Planned Start") else None,
                status="Analyzed",
                analysisResult=analysis
            )
            change_requests.append(cr)

    print(f"Successfully converted and analyzed {len(change_requests)} Change Requests.")

    # Save to references/sample_change_requests.json
    with open(SAMPLE_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump([cr.dict() for cr in change_requests], f, indent=2, default=str)

    # Save to active datastore
    with open(DATA_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump([cr.dict() for cr in change_requests], f, indent=2, default=str)

    # Refresh ticket store in memory
    ticket_store._load()
    print("Datastore refreshed successfully with all 50 Change Requests! [OK]")

if __name__ == "__main__":
    load_and_convert_csv()
