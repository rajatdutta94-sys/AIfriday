let changeRequests = [];
let currentFilter = 'all';
let currentSearch = '';
let activeCr = null;
let priorityChart = null;
let systemsChart = null;

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', async () => {
  await loadStats();
  await loadChangeRequests();
  lucide.createIcons();
});

// Load stats and render charts
async function loadStats() {
  try {
    const res = await fetch('/api/stats');
    const data = await res.json();

    document.getElementById('statTotal').innerText = data.total;
    document.getElementById('statHighRisk').innerText = data.highRisk;
    const rate = data.total > 0 ? Math.round((data.analyzed / data.total) * 100) : 0;
    document.getElementById('statAnalyzedRate').innerText = `${rate}%`;
    document.getElementById('statP1Count').innerText = data.priorities['P1-Critical'];

    if (document.getElementById('statTotalCIs')) {
      document.getElementById('statTotalCIs').innerText = data.totalUniqueCIs || Object.keys(data.systemCounts).length;
    }
    if (document.getElementById('statHighContentionCIs')) {
      document.getElementById('statHighContentionCIs').innerText = `${data.highContentionCIs || 0} high contention (≥2 CRs)`;
    }

    renderPriorityChart(data.priorities);
    renderSystemsChart(data.systemCounts);
    if (data.ciDetails) {
      renderCiRegister(data.ciDetails);
    }
    lucide.createIcons();
  } catch (err) {
    console.error('Failed to load stats:', err);
  }
}

// Render Affected Configuration Items (CIs) Contention Register
function renderCiRegister(ciDetails) {
  const container = document.getElementById('ciRegisterContainer');
  if (!container) return;
  container.innerHTML = '';

  ciDetails.forEach(ci => {
    const isHigh = ci.count >= 3;
    const isMod = ci.count === 2;
    
    let contentionBadge = `<span class="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-600">1 CR</span>`;
    let borderClass = 'border-slate-200 bg-slate-50/50';

    if (isHigh) {
      contentionBadge = `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-700 border border-rose-200">🔴 High (${ci.count} CRs)</span>`;
      borderClass = 'border-rose-200 bg-rose-50/40';
    } else if (isMod) {
      contentionBadge = `<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">🟡 Moderate (${ci.count} CRs)</span>`;
      borderClass = 'border-amber-200 bg-amber-50/40';
    }

    let typeColor = 'bg-blue-50 text-blue-700 border-blue-200';
    if (ci.type === 'Database') typeColor = 'bg-purple-50 text-purple-700 border-purple-200';
    else if (ci.type === 'Infrastructure') typeColor = 'bg-cyan-50 text-cyan-700 border-cyan-200';
    else if (ci.type === 'Third-Party Service') typeColor = 'bg-emerald-50 text-emerald-700 border-emerald-200';
    else if (ci.type === 'Frontend') typeColor = 'bg-orange-50 text-orange-700 border-orange-200';

    const crPills = (ci.crIds || []).map(id => `
      <button onclick="event.stopPropagation(); openDossierModal('${id}')" class="px-1.5 py-0.5 text-[10px] font-mono font-medium rounded bg-white hover:bg-indigo-600 hover:text-white text-indigo-700 border border-indigo-200 transition">
        ${id}
      </button>
    `).join('');

    container.innerHTML += `
      <div class="p-3 rounded-xl border ${borderClass} shadow-xs flex flex-col justify-between hover:shadow-sm transition">
        <div>
          <div class="flex items-start justify-between gap-1 mb-1.5">
            <div class="flex items-center space-x-1.5 min-w-0">
              <span class="px-1.5 py-0.5 text-[9px] font-mono font-bold rounded bg-slate-200 text-slate-800 shrink-0">${ci.id || 'CI-GEN'}</span>
              <span class="font-bold text-slate-800 text-xs tracking-tight line-clamp-1" title="${ci.name}">${ci.name}</span>
            </div>
            ${contentionBadge}
          </div>
          <div class="flex items-center space-x-1.5 mb-2">
            <span class="px-1.5 py-0.5 text-[9px] font-semibold rounded border ${typeColor}">${ci.type}</span>
            <span class="text-[10px] text-slate-400">CI Resource</span>
          </div>
        </div>
        <div class="pt-2 border-t border-slate-100/80">
          <div class="text-[10px] font-medium text-slate-500 mb-1">Impacted CRs:</div>
          <div class="flex flex-wrap gap-1">${crPills}</div>
        </div>
      </div>
    `;
  });
}

// Render Priority Tier Bar/Doughnut Chart
function renderPriorityChart(priorities) {
  const ctx = document.getElementById('priorityChart').getContext('2d');
  if (priorityChart) priorityChart.destroy();

  priorityChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['P1 Critical', 'P2 High', 'P3 Medium', 'P4 Low'],
      datasets: [{
        data: [
          priorities['P1-Critical'] || 0,
          priorities['P2-High'] || 0,
          priorities['P3-Medium'] || 0,
          priorities['P4-Low'] || 0
        ],
        backgroundColor: ['#ef4444', '#f97316', '#eab308', '#22c55e'],
        borderWidth: 2,
        borderColor: '#ffffff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 10 } } }
      },
      cutout: '65%'
    }
  });
}

// Render Systems Frequency Chart
function renderSystemsChart(systemCounts) {
  const ctx = document.getElementById('systemsChart').getContext('2d');
  if (systemsChart) systemsChart.destroy();

  const labels = Object.keys(systemCounts);
  const values = Object.values(systemCounts);

  systemsChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Affected CR Count',
        data: values,
        backgroundColor: '#6366f1',
        borderRadius: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: { beginAtZero: true, ticks: { stepSize: 1, font: { size: 10 } } },
        x: { ticks: { font: { size: 9 }, maxRotation: 45 } }
      },
      plugins: {
        legend: { display: false }
      }
    }
  });
}

// Load Change Requests from API
async function loadChangeRequests() {
  try {
    let url = '/api/cr';
    const params = new URLSearchParams();
    if (currentSearch) params.append('search', currentSearch);
    if (currentFilter !== 'all') params.append('priority', currentFilter);
    if (params.toString()) url += `?${params.toString()}`;

    const res = await fetch(url);
    changeRequests = await res.json();
    renderTable(changeRequests);
    lucide.createIcons();
  } catch (err) {
    console.error('Failed to load CRs:', err);
  }
}

// Render table rows
function renderTable(crs) {
  const tbody = document.getElementById('crTableBody');
  tbody.innerHTML = '';

  if (crs.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="py-8 text-center text-slate-400">
          No change requests matching the criteria.
        </td>
      </tr>
    `;
    return;
  }

  crs.forEach(cr => {
    const tr = document.createElement('tr');
    tr.className = 'hover:bg-slate-50/80 transition cursor-pointer';
    tr.onclick = (e) => {
      // Don't trigger if clicked on an action button directly
      if (!e.target.closest('button')) {
        openDossierModal(cr.id);
      }
    };

    const hasAnalysis = cr.analysisResult != null;
    const priority = hasAnalysis ? cr.analysisResult.impactScores.recommendedPriority : 'Pending';
    const score = hasAnalysis ? `${cr.analysisResult.impactScores.priorityScore}%` : '--';
    const risk = hasAnalysis ? cr.analysisResult.impactScores.risk : '--';

    let priorityBadgeClass = 'badge-p4';
    if (priority === 'P1-Critical') priorityBadgeClass = 'badge-p1';
    else if (priority === 'P2-High') priorityBadgeClass = 'badge-p2';
    else if (priority === 'P3-Medium') priorityBadgeClass = 'badge-p3';

    let riskBadge = `<span class="text-slate-400">--</span>`;
    if (hasAnalysis) {
      const riskColor = risk >= 4 ? 'text-rose-600 bg-rose-50 font-bold border border-rose-200' : (risk >= 3 ? 'text-amber-600 bg-amber-50 font-medium' : 'text-emerald-600 bg-emerald-50');
      riskBadge = `<span class="px-2 py-0.5 rounded-full text-[10px] ${riskColor}">${risk} / 5</span>`;
    }

    const systemsPills = cr.affectedSystems.map(s => 
      `<span class="inline-block px-1.5 py-0.5 text-[10px] bg-slate-100 text-slate-700 rounded mr-1 mb-1 font-medium border border-slate-200">${s}</span>`
    ).join('');

    const ciHeader = `<div class="text-[10px] text-indigo-700 font-semibold mb-1 flex items-center space-x-1">
      <span class="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
      <span>${cr.affectedSystems.length} Affected CIs</span>
    </div>`;

    tr.innerHTML = `
      <td class="py-3 px-4">
        <div class="font-bold text-slate-800">${cr.id}</div>
        <div class="text-slate-600 line-clamp-1 text-[11px]">${cr.title}</div>
      </td>
      <td class="py-3 px-4">
        <div class="font-medium text-slate-700">${cr.requester.name}</div>
        <div class="text-[10px] text-slate-400">${cr.requester.department}</div>
      </td>
      <td class="py-3 px-4 max-w-sm">
        ${ciHeader}
        <div class="flex flex-wrap">${systemsPills}</div>
      </td>
      <td class="py-3 px-4 text-center">
        ${riskBadge}
      </td>
      <td class="py-3 px-4 text-center">
        <span class="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${priorityBadgeClass}">${priority}</span>
        <div class="text-[10px] text-slate-400 mt-0.5">${score}</div>
      </td>
      <td class="py-3 px-4 text-center">
        <span class="inline-block px-2 py-0.5 text-[10px] rounded bg-slate-100 text-slate-600 font-medium">${cr.status}</span>
      </td>
      <td class="py-3 px-4 text-right">
        <div class="flex items-center justify-end space-x-1.5">
          <button onclick="openDossierModal('${cr.id}')" class="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded transition" title="View Dossier">
            <i data-lucide="eye" class="w-4 h-4"></i>
          </button>
          ${!hasAnalysis ? `
            <button onclick="triggerAnalysis('${cr.id}')" class="px-2 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-[10px] font-medium transition">
              Analyze
            </button>
          ` : ''}
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

// Open Dossier Modal
async function openDossierModal(crId) {
  try {
    const res = await fetch(`/api/cr/${crId}`);
    activeCr = await res.json();

    document.getElementById('dossierIdBadge').innerText = activeCr.id;
    document.getElementById('dossierTitle').innerText = activeCr.title;
    document.getElementById('dossierRequester').innerText = `Submitted by ${activeCr.requester.name} (${activeCr.requester.department}) on ${new Date(activeCr.submittedDate).toLocaleDateString()}`;

    const hasAnalysis = activeCr.analysisResult != null;
    const priority = hasAnalysis ? activeCr.analysisResult.impactScores.recommendedPriority : 'Pending Analysis';
    const pBadge = document.getElementById('dossierPriorityBadge');
    pBadge.innerText = priority;
    pBadge.className = 'px-2.5 py-1 text-xs font-bold rounded ' + (
      priority === 'P1-Critical' ? 'badge-p1' : (priority === 'P2-High' ? 'badge-p2' : (priority === 'P3-Medium' ? 'badge-p3' : 'badge-p4'))
    );

    if (hasAnalysis) {
      const a = activeCr.analysisResult;
      document.getElementById('dossierBusinessSummary').innerText = a.businessSummary;
      document.getElementById('dossierTechnicalSummary').innerText = a.technicalSummary;

      document.getElementById('scoreBv').innerText = `${a.impactScores.businessValue} / 5`;
      document.getElementById('scoreUrgency').innerText = `${a.impactScores.urgency} / 5`;
      document.getElementById('scoreComplexity').innerText = `${a.impactScores.complexity} / 5`;
      document.getElementById('scoreRisk').innerText = `${a.impactScores.risk} / 5`;
      document.getElementById('scorePriorityScore').innerText = `${a.impactScores.priorityScore}%`;

      // Dependencies
      const depContainer = document.getElementById('dependenciesContainer');
      depContainer.innerHTML = '';
      if (a.technicalDependencies.length === 0) {
        depContainer.innerHTML = `<div class="text-xs text-slate-400 italic">No external dependencies identified.</div>`;
      } else {
        a.technicalDependencies.forEach(dep => {
          const critColor = dep.criticality === 'High' ? 'text-rose-600 bg-rose-50 border-rose-200' : 'text-slate-600 bg-slate-100 border-slate-200';
          depContainer.innerHTML += `
            <div class="p-2.5 rounded-lg border border-slate-200 bg-slate-50 flex items-start justify-between">
              <div>
                <div class="flex items-center space-x-2">
                  <span class="font-bold text-slate-800 text-xs">${dep.system}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded bg-white text-slate-500 border border-slate-200 font-mono">${dep.dependencyType}</span>
                </div>
                <div class="text-[11px] text-slate-500 mt-0.5">${dep.riskNotes || 'Standard integration'}</div>
              </div>
              <span class="text-[10px] font-semibold px-2 py-0.5 rounded border ${critColor}">${dep.criticality}</span>
            </div>
          `;
        });
      }

      // Breaking changes
      const bcList = document.getElementById('dossierBreakingChanges');
      bcList.innerHTML = '';
      (a.potentialBreakingChanges || []).forEach(bc => {
        bcList.innerHTML += `<li>${bc}</li>`;
      });

      // Acceptance criteria
      const acList = document.getElementById('dossierAcceptanceCriteria');
      acList.innerHTML = '';
      (a.suggestedAcceptanceCriteria || []).forEach(ac => {
        acList.innerHTML += `<li>${ac}</li>`;
      });
    }

    // Populate feedback form with existing feedback if any
    if (activeCr.userFeedback) {
      document.getElementById('feedbackRating').value = activeCr.userFeedback.rating || 'Accepted';
      document.getElementById('feedbackPriorityOverride').value = activeCr.userFeedback.manualPriorityOverride || '';
      document.getElementById('feedbackNotes').value = activeCr.userFeedback.feedbackNotes || '';
    } else {
      document.getElementById('feedbackRating').value = 'Accepted';
      document.getElementById('feedbackPriorityOverride').value = '';
      document.getElementById('feedbackNotes').value = '';
    }

    document.getElementById('dossierModal').classList.remove('hidden');
    lucide.createIcons();
  } catch (err) {
    console.error('Failed to open dossier:', err);
  }
}

function closeDossierModal() {
  document.getElementById('dossierModal').classList.add('hidden');
}

// Trigger Analysis on unanalyzed CR
async function triggerAnalysis(crId) {
  try {
    const res = await fetch(`/api/cr/${crId}/analyze`, { method: 'POST' });
    if (res.ok) {
      await loadStats();
      await loadChangeRequests();
      openDossierModal(crId);
    }
  } catch (err) {
    console.error('Analysis trigger failed:', err);
  }
}

// Submit Human Feedback
async function submitFeedback(event) {
  event.preventDefault();
  if (!activeCr) return;

  const payload = {
    rating: document.getElementById('feedbackRating').value,
    manualPriorityOverride: document.getElementById('feedbackPriorityOverride').value || null,
    feedbackNotes: document.getElementById('feedbackNotes').value || null
  };

  try {
    const res = await fetch(`/api/cr/${activeCr.id}/feedback`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      await loadStats();
      await loadChangeRequests();
      openDossierModal(activeCr.id);
      alert('Feedback and calibration saved successfully!');
    }
  } catch (err) {
    console.error('Feedback submit failed:', err);
  }
}

// Submit New CR
async function submitNewCr(event) {
  event.preventDefault();
  const systemsStr = document.getElementById('newSystems').value;
  const systems = systemsStr ? systemsStr.split(',').map(s => s.trim()).filter(Boolean) : [];

  const payload = {
    title: document.getElementById('newTitle').value,
    requesterName: document.getElementById('newRequesterName').value,
    requesterDepartment: document.getElementById('newRequesterDept').value,
    businessJustification: document.getElementById('newJustification').value,
    rawDescription: document.getElementById('newDescription').value,
    affectedSystems: systems,
    autoAnalyze: document.getElementById('newAutoAnalyze').checked
  };

  try {
    const res = await fetch('/api/cr', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      const cr = await res.json();
      closeCreateModal();
      document.getElementById('createCrForm').reset();
      await loadStats();
      await loadChangeRequests();
      openDossierModal(cr.id);
    }
  } catch (err) {
    console.error('CR creation failed:', err);
  }
}

// Sync from Ticketing API
async function syncTicketing() {
  const btn = document.getElementById('syncTicketingBtn');
  btn.disabled = true;
  btn.classList.add('opacity-50');

  try {
    const res = await fetch('/api/ticketing/sync', { method: 'POST' });
    const data = await res.json();
    await loadStats();
    await loadChangeRequests();
    alert(data.message);
  } catch (err) {
    console.error('Ticketing sync failed:', err);
  } finally {
    btn.disabled = false;
    btn.classList.remove('opacity-50');
  }
}

// Filter Tabs
function setFilter(tier) {
  currentFilter = tier;
  document.querySelectorAll('.filter-tab').forEach(b => {
    b.className = 'filter-tab px-3 py-1.5 text-xs font-semibold rounded-lg text-slate-600 hover:bg-slate-100';
  });
  const activeBtn = document.getElementById(`filter-${tier}`);
  if (activeBtn) {
    activeBtn.className = 'filter-tab px-3 py-1.5 text-xs font-semibold rounded-lg bg-indigo-50 text-indigo-700';
  }
  loadChangeRequests();
}

function handleSearch() {
  currentSearch = document.getElementById('searchInput').value;
  loadChangeRequests();
}

// Create Modal Open/Close
function openCreateModal() {
  document.getElementById('createModal').classList.remove('hidden');
}
function closeCreateModal() {
  document.getElementById('createModal').classList.add('hidden');
}

// Natural Language Chat Drawer
function openChatDrawer() {
  document.getElementById('chatDrawer').classList.remove('hidden');
  lucide.createIcons();
}
function closeChatDrawer() {
  document.getElementById('chatDrawer').classList.add('hidden');
}

function sendQuickPrompt(promptText) {
  document.getElementById('chatInput').value = promptText;
  submitChat(new Event('submit'));
}

function askRecommendationForActiveCr() {
  if (!activeCr) return;
  openChatDrawer();
  sendQuickPrompt(`Give me recommendations and risk mitigation for ${activeCr.id}`);
}

async function submitChat(event) {
  if (event) event.preventDefault();
  const input = document.getElementById('chatInput');
  const query = input.value.trim();
  if (!query) return;

  const container = document.getElementById('chatContainer');
  // Append user bubble
  container.innerHTML += `
    <div class="flex justify-end">
      <div class="bg-indigo-600 text-white rounded-xl p-3 max-w-[85%] leading-relaxed">
        ${query}
      </div>
    </div>
  `;
  input.value = '';
  container.scrollTop = container.scrollHeight;

  // Append typing indicator
  const typingId = 'typing-' + Date.now();
  container.innerHTML += `
    <div id="${typingId}" class="bg-slate-100 rounded-xl p-3 text-slate-500 italic max-w-[85%]">
      Analyzing catalog and technical impact...
    </div>
  `;
  container.scrollTop = container.scrollHeight;

  try {
    const res = await fetch('/api/chat/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: query })
    });

    const data = await res.json();
    document.getElementById(typingId).remove();

    // Format simple markdown into HTML
    let formatted = data.answer
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/`([^`]+)`/g, '<code class="bg-slate-200 px-1 py-0.5 rounded text-[11px] font-mono">$1</code>')
      .replace(/\n\n/g, '<br><br>')
      .replace(/\n- /g, '<br>• ');

    container.innerHTML += `
      <div class="bg-slate-100 rounded-xl p-3 text-slate-800 leading-relaxed">
        ${formatted}
      </div>
    `;
    container.scrollTop = container.scrollHeight;
    lucide.createIcons();
  } catch (err) {
    document.getElementById(typingId).remove();
    container.innerHTML += `
      <div class="bg-rose-50 text-rose-700 rounded-xl p-3">
        Error getting response from assistant.
      </div>
    `;
  }
}
