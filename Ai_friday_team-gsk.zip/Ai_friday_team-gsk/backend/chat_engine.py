"""
Natural Language Query Engine over Change Requests.
Answers user queries with context from active CRs, providing intelligent recommendations,
impact assessments, and dependency conflict analysis.
"""

import os
import json
from typing import List, Dict, Any
from .models import ChangeRequest, ChatQueryResponse

def answer_query(query: str, cr_list: List[ChangeRequest]) -> ChatQueryResponse:
    """
    Process natural language query against the active CR catalog.
    Uses LLM if available, otherwise executes semantic rule-based query parser.
    """
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        try:
            return _answer_with_llm(query, cr_list, api_key)
        except Exception as e:
            print(f"[ChatEngine] LLM query failed, falling back to NLP: {e}")

    return _answer_with_nlp(query, cr_list)


def _answer_with_nlp(query: str, cr_list: List[ChangeRequest]) -> ChatQueryResponse:
    q = query.lower().strip()
    matched_crs = []

    # 1. Query for a specific CR (e.g., "CR-2026-0004" or "CR-2024-001")
    for cr in cr_list:
        if cr.id.lower() in q:
            matched_crs.append(cr.id)
            has_analysis = cr.analysisResult is not None
            score = cr.analysisResult.impactScores.priorityScore if has_analysis else 50.0
            tier = cr.analysisResult.impactScores.recommendedPriority if has_analysis else "P3-Medium"
            risk = cr.analysisResult.impactScores.risk if has_analysis else 2
            complexity = cr.analysisResult.impactScores.complexity if has_analysis else 2

            # Formulate targeted recommendation
            if tier == "P1-Critical":
                action = "🔴 **RECOMMENDED ACTION: FAST-TRACK ARB APPROVAL**"
                advice = "High business value / urgency. Enforce primary stakeholder sign-off and schedule during maintenance window."
            elif tier == "P2-High":
                action = "🟡 **RECOMMENDED ACTION: SCHEDULE FOR UPCOMING SPRINT**"
                advice = "Coordinate with service owners. Validate rollback automation before deployment."
            elif tier == "P3-Medium":
                action = "🟢 **RECOMMENDED ACTION: STANDARD BATCH DEPLOYMENT**"
                advice = "Eligible for standard automated deployment pipeline once test criteria are verified."
            else:
                action = "⚪ **RECOMMENDED ACTION: LOW PRIORITY / BACKLOG GROOMING**"
                advice = "Defer until bundled with higher-priority initiatives or off-peak cycle."

            deps_str = ", ".join([f"`{d.system}` ({d.dependencyType})" for d in cr.analysisResult.technicalDependencies]) if (has_analysis and cr.analysisResult.technicalDependencies) else ", ".join(cr.affectedSystems)
            breaking_str = cr.analysisResult.potentialBreakingChanges[0] if (has_analysis and cr.analysisResult.potentialBreakingChanges) else "No severe breaking changes identified."

            answer = (
                f"### AI Recommendation & Analysis for **{cr.id}**\n\n"
                f"**Title**: {cr.title}\n\n"
                f"{action}\n\n"
                f"- **Priority Tier**: `{tier}` (Score: {score}%)\n"
                f"- **Risk / Complexity**: Risk `{risk}/5` | Complexity `{complexity}/5`\n"
                f"- **Affected CI(s)**: `{', '.join(cr.affectedSystems)}`\n"
                f"- **Requester**: {cr.requester.name} ({cr.requester.department})\n\n"
                f"**Architectural Summary**:\n"
                f"{cr.analysisResult.technicalSummary if has_analysis else cr.rawDescription}\n\n"
                f"**Key Recommendation & Guardrails**:\n"
                f"• {advice}\n"
                f"• **Potential Risk Vector**: {breaking_str}\n"
                f"• **Verification Step**: Run smoke tests and ensure service owner confirms post-deployment validation."
            )
            return ChatQueryResponse(answer=answer, referencedCrIds=[cr.id])

    # 2. General "Recommendations", "Prioritization", "What to approve / deploy"
    if any(k in q for k in ["recommend", "recommendation", "priorit", "what should i", "suggest", "action plan", "approval", "approve", "sprint plan", "deploy first", "advice"]):
        p1_crs = [c for c in cr_list if c.analysisResult and c.analysisResult.impactScores.recommendedPriority == "P1-Critical"]
        p2_crs = [c for c in cr_list if c.analysisResult and c.analysisResult.impactScores.recommendedPriority == "P2-High"]
        high_risk_crs = [c for c in cr_list if c.analysisResult and c.analysisResult.impactScores.risk >= 4]

        # Calculate high contention CIs
        ci_freq = {}
        for c in cr_list:
            for s in c.affectedSystems:
                ci_freq[s] = ci_freq.get(s, 0) + 1
        high_contention_cis = [ci for ci, cnt in ci_freq.items() if cnt >= 3][:3]

        lines = [
            "### 🎯 Strategic Prioritization & Delivery Recommendations\n",
            "Based on the objective scoring rubric and technical dependency analysis, here is the recommended action plan:\n",
            "#### 1. 🔴 Immediate Action: Approve & Fast-Track (P1-Critical)",
        ]
        if p1_crs:
            for c in p1_crs[:4]:
                lines.append(f"- **[{c.id}]** {c.title}\n  *Affected CI: `{', '.join(c.affectedSystems)}` | Score: {c.analysisResult.impactScores.priorityScore}%*")
                matched_crs.append(c.id)
            lines.append("  *Action: Require ARB sign-off and schedule dedicated off-peak maintenance window.*\n")
        else:
            lines.append("- No critical blockers currently queued.\n")

        lines.append("#### 2. 🟡 High Priority for Upcoming Sprint (P2-High)")
        if p2_crs:
            for c in p2_crs[:3]:
                lines.append(f"- **[{c.id}]** {c.title} *(Risk: {c.analysisResult.impactScores.risk}/5)*")
                matched_crs.append(c.id)
            lines.append("  *Action: Coordinate with service owners and pre-verify rollback runbooks.*\n")

        if high_contention_cis:
            lines.append("#### 3. ⚠️ Configuration Item (CI) Contention Warning")
            lines.append(f"The following CIs are touched by 3 or more concurrent changes: **{', '.join(high_contention_cis)}**.")
            lines.append("  *Recommendation: Stagger deployment times to prevent database locking collisions or regression conflicts.*\n")

        lines.append("#### 4. 🛡️ Release Guardrails")
        lines.append("• Ensure automated rollbacks are tested for all database and infrastructure patches.")
        lines.append("• Monitor post-change telemetry for 30 minutes following implementation.")

        return ChatQueryResponse(answer="\n".join(lines), referencedCrIds=matched_crs)

    # 3. Query for High Contention CIs or Specific Systems
    # Check if query matches any known CI name
    for cr in cr_list:
        for s in cr.affectedSystems:
            if s.lower() in q and len(s) > 3:
                related = [c for c in cr_list if s.lower() in [sys.lower() for sys in c.affectedSystems]]
                matched_crs = [c.id for c in related]
                lines = [
                    f"### Analysis for Affected CI: **{s}**\n",
                    f"Found **{len(related)}** Change Request(s) touching this Configuration Item:\n"
                ]
                for c in related:
                    p = c.analysisResult.impactScores.recommendedPriority if c.analysisResult else "P3-Medium"
                    lines.append(f"- **[{c.id}]** {c.title} (`{p}`)")
                
                if len(related) >= 2:
                    lines.append(f"\n⚠️ **Contention Advisory**: High cross-change overlap detected on `{s}`. Ensure changes are deployed sequentially rather than simultaneously.")
                return ChatQueryResponse(answer="\n".join(lines), referencedCrIds=matched_crs)

    # 4. Query for Database / Schema modifications
    if any(k in q for k in ["database", "schema", "table", "sql", "migration"]):
        db_crs = []
        for cr in cr_list:
            text = f"{cr.title} {cr.rawDescription} {' '.join(cr.affectedSystems)}".lower()
            if any(k in text for k in ["schema", "database", "table", "sql", "migration", "index"]):
                db_crs.append(cr)
                matched_crs.append(cr.id)
        
        if db_crs:
            lines = [f"### 🗄️ Database & Schema Changes ({len(db_crs)} found)\n"]
            for cr in db_crs[:6]:
                tier = cr.analysisResult.impactScores.recommendedPriority if cr.analysisResult else "P3-Medium"
                lines.append(f"- **[{cr.id}]** {cr.title} — *Tier: `{tier}`*")
            lines.append("\n**AI Recommendation**: Verify index performance and ensure `ALTER TABLE` locks do not block active client sessions during deployment.")
            return ChatQueryResponse(answer="\n".join(lines), referencedCrIds=matched_crs)

    # 5. Query for High Risk / Critical CRs
    if any(k in q for k in ["high risk", "critical", "p1", "severe", "blast radius", "urgent", "risk"]):
        high_risk = [c for c in cr_list if c.analysisResult and (c.analysisResult.impactScores.risk >= 4 or c.analysisResult.impactScores.recommendedPriority == "P1-Critical")]
        if high_risk:
            matched_crs = [c.id for c in high_risk]
            lines = [f"### 🔴 High Risk & Critical Changes ({len(high_risk)} identified)\n"]
            for cr in high_risk[:6]:
                sc = cr.analysisResult.impactScores
                lines.append(f"- **[{cr.id}]** {cr.title}\n  *Priority: `{sc.recommendedPriority}` | Risk: {sc.risk}/5 | Affected CI: `{', '.join(cr.affectedSystems)}`*")
            lines.append("\n**Recommendation**: Require senior architecture lead review and ensure test validation plans are certified prior to scheduling.")
            return ChatQueryResponse(answer="\n".join(lines), referencedCrIds=matched_crs)

    # 6. Default Fallback Catalog Overview
    p1_count = sum(1 for c in cr_list if c.analysisResult and c.analysisResult.impactScores.recommendedPriority == "P1-Critical")
    p2_count = sum(1 for c in cr_list if c.analysisResult and c.analysisResult.impactScores.recommendedPriority == "P2-High")
    p3_count = sum(1 for c in cr_list if c.analysisResult and c.analysisResult.impactScores.recommendedPriority == "P3-Medium")
    p4_count = sum(1 for c in cr_list if c.analysisResult and c.analysisResult.impactScores.recommendedPriority == "P4-Low")

    matched_crs = [cr.id for cr in cr_list[:5]]
    lines = [
        f"### 📊 Change Request Catalog Summary ({len(cr_list)} Total Records)\n",
        f"- **P1-Critical**: {p1_count} requests requiring immediate review",
        f"- **P2-High**: {p2_count} planned for upcoming releases",
        f"- **P3-Medium**: {p3_count} standard maintenance requests",
        f"- **P4-Low**: {p4_count} low-impact / deferred tasks\n",
        "**Suggested Prompts**:",
        "• *'Give me priority recommendations'*",
        "• *'What is the recommendation for CR-2026-0004?'*",
        "• *'Show all database and SQL changes'*",
        "• *'Which CRs touch Kubernetes cluster?'*"
    ]
    return ChatQueryResponse(answer="\n".join(lines), referencedCrIds=matched_crs)


def _answer_with_llm(query: str, cr_list: List[ChangeRequest], api_key: str) -> ChatQueryResponse:
    from openai import OpenAI
    client = OpenAI(api_key=api_key)

    context = []
    # Feed top 15 most relevant or high-priority CRs to keep context within optimal token limits
    sorted_crs = sorted(cr_list, key=lambda c: c.analysisResult.impactScores.priorityScore if c.analysisResult else 50.0, reverse=True)
    for cr in sorted_crs[:20]:
        context.append({
            "id": cr.id,
            "title": cr.title,
            "ci": cr.affectedSystems,
            "priority": cr.analysisResult.impactScores.recommendedPriority if cr.analysisResult else "P3-Medium",
            "score": cr.analysisResult.impactScores.priorityScore if cr.analysisResult else 50.0,
            "risk": cr.analysisResult.impactScores.risk if cr.analysisResult else 2,
            "summary": cr.analysisResult.technicalSummary if cr.analysisResult else cr.rawDescription
        })

    prompt = f"""
    Context of Change Requests (Top Active):
    {json.dumps(context, indent=2)}

    User Query: {query}

    Provide an actionable, structured enterprise recommendation citing specific CR IDs and Affected CIs.
    """
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are the Principal Enterprise Change Management Advisor. Give concise, actionable prioritization recommendations."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3
    )

    answer_text = response.choices[0].message.content
    referenced = [cr.id for cr in cr_list if cr.id in answer_text]
    return ChatQueryResponse(answer=answer_text, referencedCrIds=referenced)
