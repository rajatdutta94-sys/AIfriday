"""
Ticketing System Adapter & Data Store.
Provides mock integration with Jira / ServiceNow and seeds test CRs from references/sample_change_requests.json.
"""

import json
import os
from typing import Dict, List, Optional
from .models import ChangeRequest, AnalysisResult
from .ai_engine import analyze_change_request

DATA_FILE = os.path.join(os.path.dirname(__file__), "..", "data", "change_requests.json")
SAMPLE_FILE = os.path.join(os.path.dirname(__file__), "..", "references", "sample_change_requests.json")

class TicketingStore:
    def __init__(self):
        self._store: Dict[str, ChangeRequest] = {}
        self._load()

    def _load(self):
        # 1. Try loading from persisted data
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    items = json.load(f)
                    for item in items:
                        cr = ChangeRequest(**item)
                        self._store[cr.id] = cr
                    return
            except Exception as e:
                print(f"[TicketingStore] Error reading data file: {e}")

        # 2. Otherwise seed from sample_change_requests.json
        self.reset_to_samples()

    def save(self):
        os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump([cr.dict() for cr in self._store.values()], f, indent=2, default=str)

    def reset_to_samples(self) -> int:
        self._store.clear()
        if os.path.exists(SAMPLE_FILE):
            with open(SAMPLE_FILE, "r", encoding="utf-8") as f:
                samples = json.load(f)
                for item in samples:
                    cr = ChangeRequest(**item)
                    # If sample doesn't have analysis, run AI analysis
                    if not cr.analysisResult:
                        cr.analysisResult = analyze_change_request(
                            title=cr.title,
                            business_justification=cr.businessJustification,
                            raw_description=cr.rawDescription,
                            affected_systems=cr.affectedSystems
                        )
                        cr.status = "Analyzed"
                    self._store[cr.id] = cr
            self.save()
        return len(self._store)

    def get_all(self) -> List[ChangeRequest]:
        return list(self._store.values())

    def get_by_id(self, cr_id: str) -> Optional[ChangeRequest]:
        return self._store.get(cr_id)

    def add_or_update(self, cr: ChangeRequest) -> ChangeRequest:
        self._store[cr.id] = cr
        self.save()
        return cr

    def delete(self, cr_id: str) -> bool:
        if cr_id in self._store:
            del self._store[cr_id]
            self.save()
            return True
        return False

# Global singleton instance
ticket_store = TicketingStore()
