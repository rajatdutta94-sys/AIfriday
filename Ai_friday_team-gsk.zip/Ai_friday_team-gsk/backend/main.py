"""
FastAPI Server for Change Request AI Assistant (CR-Assist).
Provides REST endpoints and serves the web dashboard UI.
"""

import os
from datetime import datetime
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from .models import (
    ChangeRequest,
    ChangeRequestCreate,
    UserFeedback,
    ChatQueryRequest,
    ChatQueryResponse
)
from .ticketing import ticket_store
from .ai_engine import analyze_change_request
from .chat_engine import answer_query

app = FastAPI(
    title="CR-Assist API",
    description="AI Assistant for Change Request Analysis, Impact Assessment & Prioritization",
    version="1.0.0"
)

# Enable CORS for local dev / frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ----------------- REST Endpoints ----------------- #

@app.get("/api/health")
def health_check():
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}

@app.get("/api/stats")
def get_stats():
    crs = ticket_store.get_all()
    total = len(crs)
    analyzed = sum(1 for c in crs if c.status == "Analyzed" or c.analysisResult)
    high_risk = sum(1 for c in crs if c.analysisResult and c.analysisResult.impactScores.risk >= 4)
    critical_p1 = sum(1 for c in crs if c.analysisResult and c.analysisResult.impactScores.recommendedPriority == "P1-Critical")
    p2 = sum(1 for c in crs if c.analysisResult and c.analysisResult.impactScores.recommendedPriority == "P2-High")
    p3 = sum(1 for c in crs if c.analysisResult and c.analysisResult.impactScores.recommendedPriority == "P3-Medium")
    p4 = sum(1 for c in crs if c.analysisResult and c.analysisResult.impactScores.recommendedPriority == "P4-Low")

    # Standard CMDB Configuration Item (CI) Catalog Registry
    ci_registry = {
        "API Gateway": {"id": "CI-INF-101", "type": "Infrastructure"},
        "Payment Service API": {"id": "CI-API-201", "type": "REST API"},
        "Order Management DB": {"id": "CI-DB-301", "type": "Database"},
        "Checkout Web App": {"id": "CI-APP-401", "type": "Frontend"},
        "Notification Service": {"id": "CI-API-202", "type": "REST API"},
        "ERP Sync Pipeline": {"id": "CI-API-203", "type": "REST API"},
        "Twilio Gateway Adapter": {"id": "CI-EXT-501", "type": "Third-Party Service"},
        "Identity Provider (IdP)": {"id": "CI-SEC-601", "type": "Security / IdP"},
        "B2B Partner Portal": {"id": "CI-APP-402", "type": "Frontend"},
        "Web Frontend SPA": {"id": "CI-APP-403", "type": "Frontend"},
        "User Profile API": {"id": "CI-API-204", "type": "REST API"},
        "Redis Cluster": {"id": "CI-INF-102", "type": "Infrastructure"},
        "MongoDB": {"id": "CI-DB-302", "type": "Database"}
    }

    # Detailed Affected CIs (Configuration Items) mapping
    ci_map = {}
    for c in crs:
        for s in c.affectedSystems:
            if s not in ci_map:
                s_lower = s.lower()
                reg_entry = ci_registry.get(s)
                if reg_entry:
                    ci_id = reg_entry["id"]
                    ci_type = reg_entry["type"]
                else:
                    ci_id = f"CI-GEN-{abs(hash(s)) % 900 + 100}"
                    ci_type = "REST API"
                    if any(k in s_lower for k in ["db", "database", "table", "sql", "mongo"]):
                        ci_type = "Database"
                    elif any(k in s_lower for k in ["app", "ui", "frontend", "web", "portal"]):
                        ci_type = "Frontend"
                    elif any(k in s_lower for k in ["twilio", "stripe", "partner", "third"]):
                        ci_type = "Third-Party Service"
                    elif any(k in s_lower for k in ["queue", "kafka", "event"]):
                        ci_type = "Message Queue"
                    elif any(k in s_lower for k in ["redis", "cluster", "cache", "gateway"]):
                        ci_type = "Infrastructure"

                ci_map[s] = {
                    "id": ci_id,
                    "name": s,
                    "type": ci_type,
                    "count": 0,
                    "crIds": []
                }
            ci_map[s]["count"] += 1
            if c.id not in ci_map[s]["crIds"]:
                ci_map[s]["crIds"].append(c.id)

    ci_list = sorted(ci_map.values(), key=lambda x: x["count"], reverse=True)
    high_contention_ci_count = sum(1 for item in ci_list if item["count"] >= 2)
    system_counts = {item["name"]: item["count"] for item in ci_list}

    return {
        "total": total,
        "analyzed": analyzed,
        "highRisk": high_risk,
        "totalUniqueCIs": len(ci_list),
        "highContentionCIs": high_contention_ci_count,
        "priorities": {
            "P1-Critical": critical_p1,
            "P2-High": p2,
            "P3-Medium": p3,
            "P4-Low": p4
        },
        "systemCounts": system_counts,
        "ciDetails": ci_list
    }

@app.get("/api/cr", response_model=List[ChangeRequest])
def list_change_requests(
    search: Optional[str] = Query(None, description="Search by title, ID, or affected system"),
    status: Optional[str] = Query(None, description="Filter by status"),
    priority: Optional[str] = Query(None, description="Filter by recommended priority")
):
    crs = ticket_store.get_all()
    if search:
        s = search.lower()
        crs = [
            c for c in crs if (
                s in c.id.lower() or
                s in c.title.lower() or
                any(s in sys.lower() for sys in c.affectedSystems)
            )
        ]
    if status:
        crs = [c for c in crs if c.status.lower() == status.lower()]
    if priority:
        crs = [
            c for c in crs if c.analysisResult and
            c.analysisResult.impactScores.recommendedPriority.lower() == priority.lower()
        ]
    return crs

@app.get("/api/cr/{cr_id}", response_model=ChangeRequest)
def get_change_request(cr_id: str):
    cr = ticket_store.get_by_id(cr_id)
    if not cr:
        raise HTTPException(status_code=404, detail=f"Change Request {cr_id} not found")
    return cr

@app.post("/api/cr", response_model=ChangeRequest)
def create_change_request(payload: ChangeRequestCreate):
    # Auto-generate ID if needed
    existing = ticket_store.get_all()
    new_id = f"CR-2024-{len(existing) + 1:03d}"
    
    cr = ChangeRequest(
        id=new_id,
        title=payload.title,
        requester={
            "name": payload.requesterName,
            "department": payload.requesterDepartment,
            "email": payload.requesterEmail
        },
        businessJustification=payload.businessJustification,
        rawDescription=payload.rawDescription,
        affectedSystems=payload.affectedSystems,
        targetReleaseDate=payload.targetReleaseDate,
        status="Pending Analysis"
    )

    if payload.autoAnalyze:
        cr.analysisResult = analyze_change_request(
            title=cr.title,
            business_justification=cr.businessJustification,
            raw_description=cr.rawDescription,
            affected_systems=cr.affectedSystems
        )
        cr.status = "Analyzed"

    ticket_store.add_or_update(cr)
    return cr

@app.post("/api/cr/{cr_id}/analyze", response_model=ChangeRequest)
def trigger_analysis(cr_id: str):
    cr = ticket_store.get_by_id(cr_id)
    if not cr:
        raise HTTPException(status_code=404, detail=f"Change Request {cr_id} not found")

    cr.analysisResult = analyze_change_request(
        title=cr.title,
        business_justification=cr.businessJustification,
        raw_description=cr.rawDescription,
        affected_systems=cr.affectedSystems
    )
    cr.status = "Analyzed"
    ticket_store.add_or_update(cr)
    return cr

@app.post("/api/cr/{cr_id}/feedback", response_model=ChangeRequest)
def submit_feedback(cr_id: str, feedback: UserFeedback):
    cr = ticket_store.get_by_id(cr_id)
    if not cr:
        raise HTTPException(status_code=404, detail=f"Change Request {cr_id} not found")

    cr.userFeedback = feedback
    if feedback.manualPriorityOverride and cr.analysisResult:
        # Update display priority to reflect human decision
        cr.analysisResult.impactScores.recommendedPriority = feedback.manualPriorityOverride
        cr.status = "Approved" if feedback.rating == "Accepted" else "In Review"

    ticket_store.add_or_update(cr)
    return cr

@app.post("/api/ticketing/sync")
def sync_ticketing():
    count = ticket_store.reset_to_samples()
    return {"message": f"Successfully synced and loaded {count} tickets from ticketing API.", "count": count}

@app.post("/api/chat/query", response_model=ChatQueryResponse)
def chat_query(req: ChatQueryRequest):
    crs = ticket_store.get_all()
    return answer_query(req.query, crs)


# ----------------- Static UI Serving ----------------- #
static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

    @app.get("/")
    def serve_dashboard():
        return FileResponse(os.path.join(static_dir, "index.html"))
