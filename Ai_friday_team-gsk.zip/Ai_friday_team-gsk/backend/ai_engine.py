"""
AI Analysis Engine for Change Requests.
Extracts technical dependencies, scores multidimensional impact, bridges business & technical context,
and suggests acceptance criteria. Works with OpenAI/Gemini/Ollama or intelligent offline heuristic fallback.
"""

import os
import json
import re
from typing import Dict, Any, List
from .models import AnalysisResult, ImpactScores, Dependency
from .scoring import calculate_priority_score, map_score_to_priority

def analyze_change_request(
    title: str,
    business_justification: str,
    raw_description: str,
    affected_systems: List[str]
) -> AnalysisResult:
    """
    Main analysis pipeline. Checks if LLM is enabled (via OPENAI_API_KEY or OLLAMA_HOST),
    otherwise executes the built-in intelligent heuristic engine.
    """
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        try:
            return _analyze_with_openai(title, business_justification, raw_description, affected_systems, api_key)
        except Exception as e:
            print(f"[AI-Engine] LLM invocation failed, falling back to heuristic engine: {e}")

    # Fallback / deterministic intelligent analysis
    return _analyze_with_heuristic(title, business_justification, raw_description, affected_systems)


def _analyze_with_heuristic(
    title: str,
    business_justification: str,
    raw_description: str,
    affected_systems: List[str]
) -> AnalysisResult:
    """
    Deterministic NLP & Heuristic Engine modeling the rules in references/impact_rubric.md.
    """
    combined_text = f"{title} {business_justification} {raw_description}".lower()

    # 1. Detect Business Value (1 to 5)
    bv = 2
    if any(k in combined_text for k in ["compliance", "soc2", "gdpr", "hipaa", "audit finding", "legal", "critical outage", "revenue drop"]):
        bv = 5
    elif any(k in combined_text for k in ["revenue", "sales", "apac", "emea", "conversion", "b2b partner", "enterprise account"]):
        bv = 4
    elif any(k in combined_text for k in ["reduce no-show", "satisfaction", "efficiency", "patient", "customer request"]):
        bv = 3
    elif any(k in combined_text for k in ["dark mode", "ui tweak", "color", "styling", "cosmetic", "spacing"]):
        bv = 2

    # 2. Detect Urgency (1 to 5)
    urgency = 2
    if any(k in combined_text for k in ["immediate", "exploit", "outage", "security audit", "critical finding", "p1"]):
        urgency = 5
    elif any(k in combined_text for k in ["hard deadline", "launch", "soc2", "next sprint", "sunset", "deprecat"]):
        urgency = 4
    elif any(k in combined_text for k in ["scheduled", "q4", "planned", "standard release"]):
        urgency = 3
    elif any(k in combined_text for k in ["backlog", "low priority", "convenience"]):
        urgency = 1

    # 3. Detect Complexity (1 to 5)
    complexity = 2
    has_db = any(k in combined_text for k in ["schema", "database", "table", "column", "migration", "sql", "orders table"])
    has_auth_or_payment = any(k in combined_text for k in ["oauth", "pkce", "token", "auth", "stripe", "gateway", "payment intents", "sca"])
    multiple_systems = len(affected_systems) >= 3

    if (has_db and has_auth_or_payment) or multiple_systems:
        complexity = 4 if len(affected_systems) < 5 else 5
    elif has_db or has_auth_or_payment:
        complexity = 3
    elif any(k in combined_text for k in ["dark mode", "text", "template", "copy", "sms"]):
        complexity = 1

    # 4. Detect Blast Radius & Risk (1 to 5)
    risk = 2
    if any(k in combined_text for k in ["token", "session", "payment", "stripe", "credit card", "security", "sha-1", "b2b partner"]):
        risk = 4 if not has_db else 5
    elif has_db or any(k in combined_text for k in ["breaking", "decommission", "sunset"]):
        risk = 4
    elif any(k in combined_text for k in ["notification", "sms", "email"]):
        risk = 2
    elif any(k in combined_text for k in ["dark mode", "css", "theme"]):
        risk = 1

    # Calculate Priority Score and Tier
    priority_score = calculate_priority_score(bv, urgency, complexity, risk)
    recommended_priority = map_score_to_priority(priority_score)

    impact_scores = ImpactScores(
        businessValue=bv,
        urgency=urgency,
        complexity=complexity,
        risk=risk,
        priorityScore=priority_score,
        recommendedPriority=recommended_priority
    )

    # Extract Dependencies
    dependencies: List[Dependency] = []
    for sys in affected_systems:
        sys_lower = sys.lower()
        if "db" in sys_lower or "database" in sys_lower:
            dependencies.append(Dependency(
                system=sys,
                dependencyType="Database",
                criticality="High" if has_db else "Medium",
                riskNotes="Schema alter statement may require lock window or rolling migration."
            ))
        elif "api" in sys_lower or "service" in sys_lower or "gateway" in sys_lower:
            dependencies.append(Dependency(
                system=sys,
                dependencyType="REST API",
                criticality="High" if "payment" in sys_lower or "auth" in sys_lower else "Medium",
                riskNotes="Contract compatibility check required across upstream and downstream clients."
            ))
        elif "queue" in sys_lower or "kafka" in sys_lower or "event" in sys_lower:
            dependencies.append(Dependency(
                system=sys,
                dependencyType="Message Queue",
                criticality="Medium",
                riskNotes="Async event schema serialization validation needed."
            ))
        elif "stripe" in sys_lower or "twilio" in sys_lower or "partner" in sys_lower or "third" in sys_lower:
            dependencies.append(Dependency(
                system=sys,
                dependencyType="Third-Party Service",
                criticality="High" if "stripe" in sys_lower else "Medium",
                riskNotes="External API rate limits, webhooks, and sandbox certification constraints."
            ))
        else:
            dependencies.append(Dependency(
                system=sys,
                dependencyType="Frontend" if "app" in sys_lower or "ui" in sys_lower else "Infrastructure",
                criticality="Low" if "ui" in sys_lower else "Medium",
                riskNotes="Client-side rendering, cross-browser compatibility, and state cache."
            ))

    # Breaking changes identification
    breaking_changes = []
    if "deprecat" in combined_text or "sunset" in combined_text or "decommission" in combined_text:
        breaking_changes.append("Decommissioning legacy endpoints will break unmigrated client integrations.")
    if has_db:
        breaking_changes.append("Database schema migration requires backward-compatible column defaults during rollout.")
    if "stripe" in combined_text:
        breaking_changes.append("Upgrade to 3D Secure / PaymentIntents requires mandatory user authentication challenges on cards.")
    if not breaking_changes:
        breaking_changes.append("No critical backwards-incompatible breaking changes identified at initial review.")

    # Dual Summaries
    business_summary = (
        f"This request ({title}) targets {business_justification.strip().rstrip('.')}. "
        f"It has been classified with a business value rating of {bv}/5 and urgency rating of {urgency}/5, "
        f"yielding a recommended priority tier of {recommended_priority}."
    )

    technical_summary = (
        f"Implementation impacts {len(affected_systems)} system(s): {', '.join(affected_systems)}. "
        f"Technical complexity is assessed at {complexity}/5 with risk level {risk}/5. "
        + ("Includes database schema modifications. " if has_db else "")
        + ("Involves security/auth critical paths. " if has_auth_or_payment else "")
    )

    # Acceptance Criteria
    acceptance_criteria = [
        f"Verify core workflow execution across {', '.join(affected_systems[:2])}.",
        "Validate backward compatibility with existing active client sessions.",
        "Ensure telemetry events and audit logs capture new transaction states.",
        "Perform regression tests on integrated downstream endpoints."
    ]

    return AnalysisResult(
        businessSummary=business_summary,
        technicalSummary=technical_summary,
        technicalDependencies=dependencies,
        impactScores=impact_scores,
        potentialBreakingChanges=breaking_changes,
        suggestedAcceptanceCriteria=acceptance_criteria
    )


def _analyze_with_openai(
    title: str,
    business_justification: str,
    raw_description: str,
    affected_systems: List[str],
    api_key: str
) -> AnalysisResult:
    """Invokes OpenAI with structured JSON output matching schema."""
    from openai import OpenAI
    client = OpenAI(api_key=api_key)

    prompt = f"""
    Title: {title}
    Business Justification: {business_justification}
    Raw Description: {raw_description}
    Affected Systems: {json.dumps(affected_systems)}

    Return strictly valid JSON adhering to the following schema:
    {{
      "businessSummary": "string",
      "technicalSummary": "string",
      "technicalDependencies": [
        {{"system": "string", "dependencyType": "Database|REST API|Message Queue|Third-Party Service|Frontend|Infrastructure", "criticality": "High|Medium|Low", "riskNotes": "string"}}
      ],
      "impactScores": {{
        "businessValue": 1-5,
        "urgency": 1-5,
        "complexity": 1-5,
        "risk": 1-5,
        "priorityScore": float,
        "recommendedPriority": "P1-Critical|P2-High|P3-Medium|P4-Low"
      }},
      "potentialBreakingChanges": ["string"],
      "suggestedAcceptanceCriteria": ["string"]
    }}
    """
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a Principal Enterprise Architect analyzing change requests. Output pure JSON."},
            {"role": "user", "content": prompt}
        ],
        response_format={"type": "json_object"},
        temperature=0.2
    )

    data = json.loads(response.choices[0].message.content)
    # Recalculate deterministic score to enforce rubric integrity
    bv = data["impactScores"]["businessValue"]
    urgency = data["impactScores"]["urgency"]
    complexity = data["impactScores"]["complexity"]
    risk = data["impactScores"]["risk"]
    calc_score = calculate_priority_score(bv, urgency, complexity, risk)
    calc_priority = map_score_to_priority(calc_score)

    data["impactScores"]["priorityScore"] = calc_score
    data["impactScores"]["recommendedPriority"] = calc_priority
    return AnalysisResult(**data)
