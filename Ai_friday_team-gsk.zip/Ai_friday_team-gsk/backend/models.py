from typing import List, Optional, Literal
from pydantic import BaseModel, Field
from datetime import datetime

class RequesterInfo(BaseModel):
    name: str
    department: str
    email: Optional[str] = None

class Dependency(BaseModel):
    system: str
    dependencyType: Literal["Database", "REST API", "Message Queue", "Third-Party Service", "Frontend", "Infrastructure"]
    criticality: Literal["High", "Medium", "Low"]
    riskNotes: Optional[str] = None

class ImpactScores(BaseModel):
    businessValue: int = Field(..., ge=1, le=5, description="1 to 5 scale")
    urgency: int = Field(..., ge=1, le=5, description="1 to 5 scale")
    complexity: int = Field(..., ge=1, le=5, description="1 to 5 scale")
    risk: int = Field(..., ge=1, le=5, description="1 to 5 scale")
    priorityScore: float = Field(..., ge=0.0, le=100.0)
    recommendedPriority: Literal["P1-Critical", "P2-High", "P3-Medium", "P4-Low"]

class AnalysisResult(BaseModel):
    businessSummary: str
    technicalSummary: str
    technicalDependencies: List[Dependency] = []
    impactScores: ImpactScores
    potentialBreakingChanges: List[str] = []
    suggestedAcceptanceCriteria: List[str] = []
    analyzedAt: datetime = Field(default_factory=datetime.utcnow)

class UserFeedback(BaseModel):
    rating: Literal["Accepted", "Modified", "Rejected"]
    manualPriorityOverride: Optional[Literal["P1-Critical", "P2-High", "P3-Medium", "P4-Low"]] = None
    feedbackNotes: Optional[str] = None
    updatedAt: datetime = Field(default_factory=datetime.utcnow)

class ChangeRequest(BaseModel):
    id: str
    title: str
    requester: RequesterInfo
    businessJustification: str
    rawDescription: str
    affectedSystems: List[str] = []
    targetReleaseDate: Optional[str] = None
    submittedDate: datetime = Field(default_factory=datetime.utcnow)
    status: Literal["Draft", "Pending Analysis", "Analyzed", "Approved", "In Review", "Rejected"] = "Pending Analysis"
    analysisResult: Optional[AnalysisResult] = None
    userFeedback: Optional[UserFeedback] = None

class ChangeRequestCreate(BaseModel):
    title: str
    requesterName: str
    requesterDepartment: str
    requesterEmail: Optional[str] = None
    businessJustification: str
    rawDescription: str
    affectedSystems: List[str] = []
    targetReleaseDate: Optional[str] = None
    autoAnalyze: bool = True

class ChatQueryRequest(BaseModel):
    query: str

class ChatQueryResponse(BaseModel):
    answer: str
    referencedCrIds: List[str] = []
