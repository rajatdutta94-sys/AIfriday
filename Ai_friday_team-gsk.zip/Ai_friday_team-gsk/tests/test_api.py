import os
import sys

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from starlette.testclient import TestClient
from backend.main import app

def test_api_endpoints():
    client = TestClient(app)

    # 1. Health check
    res = client.get("/api/health")
    assert res.status_code == 200
    assert res.json()["status"] == "healthy"

    # 2. Stats
    res = client.get("/api/stats")
    assert res.status_code == 200
    stats = res.json()
    assert stats["total"] > 0
    print(f"Stats check passed: {stats['total']} CRs loaded.")

    # 3. List CRs
    res = client.get("/api/cr")
    assert res.status_code == 200
    crs = res.json()
    assert len(crs) > 0
    first_cr = crs[0]
    print(f"List CRs passed: First CR is {first_cr['id']} - {first_cr['title'][:30]}...")

    # 4. Chat query
    res = client.post("/api/chat/query", json={"query": "Which CRs modify database schemas?"})
    assert res.status_code == 200
    chat_resp = res.json()
    assert "answer" in chat_resp
    assert len(chat_resp["answer"]) > 0
    print("Chat query check passed.")

    # 5. Submit new CR
    payload = {
        "title": "Automated Test CR: Add Redis Cache",
        "requesterName": "DevOps Bot",
        "requesterDepartment": "Cloud Platform",
        "businessJustification": "Reduce latency by 40% under peak load",
        "rawDescription": "Introduce Redis cluster in front of MongoDB and update API gateway routes",
        "affectedSystems": ["API Gateway", "Redis Cluster", "MongoDB"],
        "autoAnalyze": True
    }
    res = client.post("/api/cr", json=payload)
    assert res.status_code == 200
    new_cr = res.json()
    assert new_cr["status"] == "Analyzed"
    assert new_cr["analysisResult"] is not None
    print(f"New CR creation & auto-analysis check passed: ID {new_cr['id']}")

    print("All API integration tests passed successfully! [OK]")

if __name__ == "__main__":
    test_api_endpoints()
