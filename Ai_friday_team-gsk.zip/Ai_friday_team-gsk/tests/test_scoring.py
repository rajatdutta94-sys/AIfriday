import os
import sys

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from backend.scoring import calculate_priority_score, map_score_to_priority
from backend.ai_engine import analyze_change_request

def test_critical_p1_scoring():
    # Maximum value (5), High Urgency (5), Moderate Complexity (3), High Risk (4)
    # Score = (5*0.35 + 5*0.25 + 3*0.20 + 2*0.20) * 20 = (1.75 + 1.25 + 0.60 + 0.40) * 20 = 4.0 * 20 = 80.0
    score = calculate_priority_score(business_value=5, urgency=5, complexity=2, risk=2)
    # (1.75 + 1.25 + 0.8 + 0.8) * 20 = 4.6 * 20 = 92.0
    assert score >= 82.0
    assert map_score_to_priority(score) == "P1-Critical"

def test_low_p4_scoring():
    score = calculate_priority_score(business_value=1, urgency=1, complexity=5, risk=5)
    # (0.35 + 0.25 + 0.20 + 0.20) * 20 = 1.0 * 20 = 20.0
    assert score < 45.0
    assert map_score_to_priority(score) == "P4-Low"

def test_medium_p3_scoring():
    # BV=3, U=3, C=3, R=3
    # (3*0.35 + 3*0.25 + 3*0.20 + 3*0.20) * 20 = (1.05 + 0.75 + 0.60 + 0.60) * 20 = 3.0 * 20 = 60.0
    score = calculate_priority_score(business_value=3, urgency=3, complexity=3, risk=3)
    assert score == 60.0
    assert map_score_to_priority(score) == "P3-Medium"

def test_ai_engine_database_detection():
    result = analyze_change_request(
        title="Add user column to orders table",
        business_justification="Improve audit compliance",
        raw_description="Alter database schema and update payment REST API",
        affected_systems=["Payment Gateway", "Orders DB"]
    )
    # Should detect database dependency
    types = [d.dependencyType for d in result.technicalDependencies]
    assert "Database" in types
    assert len(result.potentialBreakingChanges) > 0
    assert result.impactScores.priorityScore > 0

if __name__ == "__main__":
    test_critical_p1_scoring()
    test_low_p4_scoring()
    test_medium_p3_scoring()
    test_ai_engine_database_detection()
    print("All scoring & AI engine tests passed successfully! [OK]")
