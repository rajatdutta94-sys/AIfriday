# Change Request Scoring Rubric & Impact Assessment Guidelines

This document specifies the objective criteria used by the **CR-Assist AI engine** to eliminate subjective bias, accurately score incoming change requests, and recommend transparent priorities.

---

## 1. Multi-Dimensional Scoring Dimensions (1 to 5 Scale)

### 1.1. Business Value ($BV$)
Measures financial, operational, strategic, or regulatory gain.

| Score | Level | Description & Examples |
| :---: | :--- | :--- |
| **5** | **Critical / Regulatory** | Direct legal/regulatory compliance mandate (GDPR, HIPAA, SOC2), severe revenue protection, or operational blocker affecting all users. |
| **4** | **High Value** | Unlocks significant new revenue, onboarding high-value enterprise accounts, or eliminates major operational bottlenecks. |
| **3** | **Moderate Value** | Improves user satisfaction, incremental efficiency gain, or feature enhancement requested by multiple clients. |
| **2** | **Minor Improvement** | Cosmetic UI enhancement, minor internal workflow convenience, or edge-case optimization. |
| **1** | **Negligible** | Nice-to-have cosmetic tweak with minimal measurable business return. |

---

### 1.2. Urgency ($U$)
Measures timeline sensitivity and penalty of delay.

| Score | Level | Description |
| :---: | :--- | :--- |
| **5** | **Immediate (48h - 1 wk)** | Active outage, severe security CVE vulnerability under active exploit, or hard contract deadline with imminent penalty. |
| **4** | **High (Next Sprint)** | Necessary for upcoming major product launch or quarterly audit. |
| **3** | **Normal (1-2 Sprints)** | Standard release cycle; reasonable delay does not cause business harm. |
| **2** | **Low (> 1-2 Months)** | Can be deferred to future milestone without noticeable impact. |
| **1** | **Backlog Only** | Opportunistic item; can sit in backlog indefinitely. |

---

### 1.3. Technical Complexity ($C$)
Measures cognitive load, architectural changes, and effort involved.

| Score | Level | Technical Attributes |
| :---: | :--- | :--- |
| **5** | **Architectural Overhaul** | Database schema migration with locking risks, cross-microservice protocol change, core auth/payment refactor, or multi-team orchestration. |
| **4** | **Complex** | Changes across multiple microservices or synchronous APIs; requires custom data transformations or caching changes. |
| **3** | **Moderate** | Changes confined to 1–2 services; standard CRUD additions; backwards-compatible API additions. |
| **2** | **Simple** | Minor logic adjustment, configuration change, or isolated frontend component alteration. |
| **1** | **Trivial** | Text/copy changes, CSS styling tweak, or template variable mapping. |

---

### 1.4. Implementation & Blast-Radius Risk ($R$)
Measures the likelihood and consequence of unintended regressions or downtime.

| Score | Level | Risk Indicators |
| :---: | :--- | :--- |
| **5** | **Severe Blast Radius** | Single Point of Failure (SPOF) component, financial calculation engine, live customer authentication, irreversible data mutation. |
| **4** | **High Risk** | Core transactional flow (checkout, cart, billing, clinical dispatch), external B2B partner contracts affected. |
| **3** | **Moderate Risk** | Standard business logic with automated test coverage; rollback plan straightforward. |
| **2** | **Low Risk** | Non-critical background asynchronous job, internal admin dashboard feature. |
| **1** | **Isolated / Zero Risk** | Static content, decoupled feature flag, zero runtime regression hazard. |

---

## 2. Priority Calculation Algorithm

To determine an objective Priority Score (0–100), the model uses a weighted formula where high value and urgency increase priority, while high complexity and risk penalize immediate unhedged deployment unless value warrants it:

$$\text{Priority Score} = \left( BV \times 0.35 + U \times 0.25 + (6 - C) \times 0.20 + (6 - R) \times 0.20 \right) \times 20$$

### Priority Tier Mapping

| Priority Score Range | Recommended Category | Action & SLA |
| :---: | :---: | :--- |
| **$\ge 82$** | **P1 - Critical** | Fast-track for immediate Architecture Review Board (ARB) & current sprint allocation. |
| **$65 - 81$** | **P2 - High** | Plan for upcoming sprint; prioritize dependency validation. |
| **$45 - 64$** | **P3 - Medium** | Queue for standard backlog grooming; review technical trade-offs. |
| **$< 45$** | **P4 - Low** | Defer or reject unless bundled with a larger related initiative. |

---

## 3. Technical Dependency Criticality Classification

- **High Criticality**: Direct synchronous runtime dependency. If the dependent service fails, the entire transaction or user journey fails.
- **Medium Criticality**: Asynchronous or non-blocking dependency with fallback or retry queue (e.g., email notification, event bus).
- **Low Criticality**: Ancillary telemetry, analytics tracking, or cached read replica with graceful degradation.
