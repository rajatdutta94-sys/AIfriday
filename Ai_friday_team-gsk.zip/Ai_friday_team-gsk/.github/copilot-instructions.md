# Workspace Instructions for GitHub Copilot & Coding Agents

You are developing the **Change Request AI Assistant (CR-Assist)** for this project.

### Core Architecture & Guidance:
1. **Master Prompt & Specs**: Always follow [PROMPT.md](file:///c:/Users/GenAIDELLUCERNAUSR53/Documents/Ai_friday_team-gsk/PROMPT.md) and [INSTRUCTIONS.md](file:///c:/Users/GenAIDELLUCERNAUSR53/Documents/Ai_friday_team-gsk/INSTRUCTIONS.md).
2. **Data Schema**: Refer strictly to [references/change_request_schema.json](file:///c:/Users/GenAIDELLUCERNAUSR53/Documents/Ai_friday_team-gsk/references/change_request_schema.json).
3. **Scoring Logic**: Always adhere to the priority scoring formula and 1-5 rubrics documented in [references/impact_rubric.md](file:///c:/Users/GenAIDELLUCERNAUSR53/Documents/Ai_friday_team-gsk/references/impact_rubric.md).
4. **LLM Prompts**: Use prompt patterns from [references/llm_prompts.md](file:///c:/Users/GenAIDELLUCERNAUSR53/Documents/Ai_friday_team-gsk/references/llm_prompts.md).
5. **Sample Datasets**: Seed data is available in [references/sample_change_requests.json](file:///c:/Users/GenAIDELLUCERNAUSR53/Documents/Ai_friday_team-gsk/references/sample_change_requests.json).

### Implementation Principles:
- Produce clean, modern, type-safe code.
- Implement robust error handling and fallback modes so the application functions even when offline or if API keys are missing.
- Provide clear visual indicators (badges, cards, charts) for business vs. technical impact.
