"""
CR-Assist Entry Point Launcher
Run: python run.py
Then open http://localhost:8000 in your browser.
"""

import uvicorn

if __name__ == "__main__":
    print("=" * 60)
    print("🚀 Starting CR-Assist: Change Request AI Assistant")
    print("📍 Dashboard URL: http://localhost:8000")
    print("📖 API Docs:      http://localhost:8000/docs")
    print("=" * 60)
    uvicorn.run("backend.main:app", host="127.0.0.1", port=8000, reload=True)
