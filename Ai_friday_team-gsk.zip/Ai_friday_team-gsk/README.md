# CR-Assist | Change Request AI Assistant

> **Web-based AI Assistant** that processes enterprise change requests, generates dual business/technical summaries, maps technical dependencies, scores impact & risks using an objective rubric, and recommends intelligent prioritization.

---

## 🌟 Key Features

1. **Dual Perspective Summaries**: Bridges communication gaps with separate **Business Executive Summaries** (non-technical value, outcome) and **Technical Architecture Summaries** (microservices, database changes, contract risks).
2. **Hidden Technical Dependency Mapping**: Surfaces direct coupling across Databases, REST APIs, Message Queues, Third-party vendors, and UI clients.
3. **Objective Weighted Prioritization**: Eliminates subjective bias using a multi-dimensional rubric (Business Value, Urgency, Complexity, Risk) mapped to **P1-Critical**, **P2-High**, **P3-Medium**, and **P4-Low**.
4. **Natural Language Catalog Querying**: Ask questions like *"Which CRs modify database schemas?"*, *"Show all high-risk changes"*, or *"What are the dependencies for CR-2024-001?"*.
5. **Interactive Enterprise Dashboard**: Visualizes priority tier distributions and affected system frequency charts with filterable tables.
6. **Ticketing API Sync & Seed Data**: Integrated with mock Jira / ServiceNow REST synchronization loaded with realistic test cases.
7. **Human-in-the-Loop Calibration**: Engineering leads can review, override priorities, add rationale notes, and train future heuristic weights.

---

## 🚀 Quick Start (Running in VS Code)

### Option 1: Run via Terminal
```powershell
python run.py
```
Open **[http://localhost:8000](http://localhost:8000)** in your browser.

### Option 2: Run via VS Code Task
- Press `Ctrl + Shift + B` (or `Cmd + Shift + B` on Mac) to run the default build task: **"Start CR-Assist Server"**.

### Option 3: Run Automated Tests
```powershell
python tests/test_api.py
```

---

## 📂 Project Architecture

```text
Ai_friday_team-gsk/
├── backend/
│   ├── ai_engine.py          # AI analysis pipeline (LLM + offline heuristic engine)
│   ├── chat_engine.py        # Natural language query engine
│   ├── models.py             # Pydantic data schemas
│   ├── scoring.py            # Objective priority scoring calculation
│   ├── ticketing.py          # Jira/ServiceNow mock sync and persistence store
│   ├── main.py               # FastAPI server and REST endpoints
│   └── static/
│       ├── index.html        # Modern enterprise dashboard UI
│       └── app.js            # Reactive UI logic, Chart.js, modal dossiers
├── references/
│   ├── change_request_schema.json  # JSON schema for CRs & analysis
│   ├── sample_change_requests.json # 4 enterprise seed CRs
│   ├── impact_rubric.md            # Multi-dimensional scoring criteria & formulas
│   └── llm_prompts.md              # System prompts & JSON templates
├── tests/
│   ├── test_scoring.py       # Scoring calculation tests
│   └── test_api.py           # REST endpoints & integration tests
├── .vscode/
│   ├── settings.json         # Workspace settings
│   └── tasks.json            # One-click VS Code launch tasks
├── .github/
│   └── copilot-instructions.md # Auto-context for GitHub Copilot
├── PROMPT.md                 # Master prompt for AI coding agents
├── INSTRUCTIONS.md           # Deep dive architecture & integration guide
└── run.py                    # Root one-click launcher
```
